
**Admin Login Details**

* Username: admin

* Password: Password@123

#
