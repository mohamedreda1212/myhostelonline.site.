<?php
    $dbuser="user";
    $dbpass="userpassword";
    $host="mysql";
    $db="hostelmsphp";
    $mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>